SG-CYBERINTEL FORENSIC SHIELD — VERSION 1.0

Run:
- Extract the ZIP.
- Open index.html in a modern browser.
- For Web Crypto SHA-256 support, use a secure context (HTTPS or localhost).
- On Android, open in Chrome. You can host the folder on a static HTTPS host
  and add the page to the home screen.

Features:
- Local SHA-256 fingerprint for a selected evidence file.
- JSON evidence manifest export.
- Compare a file against a previously recorded SHA-256 fingerprint.
- Local heuristic review of pasted, redacted chat text.
- Manual Android security checklist.
- In-session event journal.

Privacy:
- This static prototype has no server integration and does not upload selected
  files or pasted text. Do not paste sensitive information into shared devices.

Limitations:
- Not an antivirus, EDR, mobile threat defence product, forensic suite or
  certified evidence-management system.
- It cannot guarantee protection against all attacks or detect all spyware.
- A hash proves only that the compared bytes match; it does not prove source,
  authorship, truth, timestamp or admissibility.
- Do not alter, delete or conceal potential evidence. Preserve original devices
  and consult a qualified examiner where evidential integrity matters.
